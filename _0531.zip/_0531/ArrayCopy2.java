package _0531;



public class ArrayCopy2 {

	public static void main(String[] args) {
		int[] array1 = {10, 20, 30, 40, 50};
		int[] array2 = {1, 2, 3, 4, 5};
		
		
		try {
		System.arraycopy(array1, 3, array2, 2, 1);
		}
		catch
			 (ArrayIndexOutOfBoundsException e) {
		}
		
		for(int i = 0; i < array2.length; i++) {
			System.out.println(array2[i]);
		}
		
		Book[] book1 = new Book[3];
		Book[] book2 = new Book[3];
		
		book1[0] = new Book("태백산맥");
		book1[1] = new Book("차령산맥");
		book1[2] = new Book("계백산맥");
		
		System.arraycopy(book1,  0, book2, 0, book2.length);
		
		
	}

}
