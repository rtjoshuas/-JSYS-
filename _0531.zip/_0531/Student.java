package _0531;

public class Student {
		 String name;
		
		public Student(String name) {
			this.name = name;
		}

		
}
