package _0531;

public class GenericBoxTest {

	public static void main(String[] args) {

		Box box = new Box();
		box.set("안녕");;
		box.set(new Integer(100));
		String str = (String)box.get();

		
		Box2<String> box2 = new Box2();
		Box2<String> box3 = new Box2<String>();
		box.set("안녕");
		str = box2.get();
	}
	

	

}


class Box {
	private Object object;
	public void set(Object object) {this.object = object;}
	public Object get() {return object;}
}


class Box2<String> {
	private String str;
	public void set(String s) {this.str = s;}
	public String get() {return str;}
}

