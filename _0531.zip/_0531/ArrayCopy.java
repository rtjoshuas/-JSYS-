package _0531;



public class ArrayCopy {

	public static void main(String[] args) {

		
		Book[] book1 = new Book[3];
		Book[] book2 = new Book[3];
		
		book1[0] = new Book("태백산맥");
		book1[1] = new Book("차령산맥");
		book1[2] = new Book("계백산맥");
		
		System.arraycopy(book1,  0, book2, 0, book2.length);
		
		for(Book b: book2) {
			System.out.println(b.name);
		}
		System.out.println("얕은복사 참조 (레퍼런스) 복사");
		// book1 0 번 
		book1[0].name = "구로산맥";// 얕은 복사 대입만 하면 된다
		
		for(Book b: book1) {
			System.out.println(b.name);
		}
		for(Book b: book2) {
			System.out.println(b.name);
		}
		
		
		System.out.println("깊은복사(객체생성)====");
		
		book1[0] = new Book("한라산맥"); //깊은 복사 new 를 사용해라
		
		for(Book b: book1) {
			System.out.println(b.name);
		}
		for(Book b: book2) {
			System.out.println(b.name);
		}
		
		
	}

}
