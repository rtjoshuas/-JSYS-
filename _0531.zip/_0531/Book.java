package _0531;

class Book {
	String name;
	public Book(String n) {
		this.name = n;
	}
}

