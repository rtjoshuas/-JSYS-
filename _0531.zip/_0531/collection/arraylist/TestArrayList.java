package collection.arraylist;

import java.util.ArrayList;

import collection.Member;

public class TestArrayList extends ArrayList<Member> {

	@Override
	public Member get(int index) {
		// TODO Auto-generated method stub
		return super.get(index);
	}

	@Override
	public boolean add(Member e) {
	
		return super.add(e);
	}

	@Override
	public Member remove(int index) {
		// TODO Auto-generated method stub
		return super.remove(index);
	}
		
	

}
