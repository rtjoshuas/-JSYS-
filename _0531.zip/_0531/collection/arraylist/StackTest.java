package collection.arraylist;

import java.util.ArrayList;

import collection.Member;

class MyStack{
	
	private ArrayList<Member> arrayStack = new ArrayList<Member>();
	
	public void push(Member data) {
		arrayStack.add(data);
	}
	
	public Member pop() {
		int len = arrayStack.size();
		if(len == 0 ) { 
			System.out.println("스택이 비었습니다");
			return null;
		}
		
		return(arrayStack.remove(len-1));
	}
}

public class StackTest {

	public static void main(String[] args) {

		MyStack stack = new MyStack();
		stack.push(new Member(1, "홍길동"));
		stack.push(new Member(2, "이겨라"));
		stack.push(new Member(3, "존버"));
		
		System.out.println(stack.pop());
		System.out.println(stack.pop());
		System.out.println(stack.pop());
	}
}