package CH4;

public class SwitchCase2 {

	public static void main(String[] args) {
/*		String medal = "Gold";
		
		switch(medal) {
		case "Gold":
			System.out.println("금메달 입니다.");
			break;
		case "Silver":
			System.out.println("은메달 입니다.");
			break;
		case "Bronze":
			System.out.println("동메달 입니다.");
			break;
		default:
			System.out.println("메달이 없습니다.");
			break;*/
			
			
			String Guidance = "3F";
			
		switch(Guidance) {
		case "1F" :
			System.out.println("1층 입니다.");
			break;
		case "2F" :
			System.out.println("2층 입니다.");
			break;
		case "3F" :
			System.out.println("3층 입니다.");
			break;
		case "4F" :
			System.out.println("4층 입니다.");
			break;
		default :
			System.out.println("5층 입니다.");
			break;
		}
		System.out.println("안녕히 가세요");
		}

	}
/*
}*/
