package _0527;

public class Desktop extends Computer2 {
	
	public static void main(String[] args) {

		//Computer c1 = new Computer();
	
		Computer2 c2 = new Desktop();
		
		
		
		
		
		c2.display(); 
		c2.typing();
	}
	@Override
	void display() {
		// TODO Auto-generated method stub
		System.out.println("DeskTop display()");
	}

	@Override
	void typing() {
		System.out.println("DeskTop typing()");
	}


}


