package _0527;

public class Calculator {
	double r;
	
	public Calculator(double r) {
		this.r = r;
	}
	
	public void areaCircle(double r) {
		r = 3.1415*r*r;
		
	}

}
