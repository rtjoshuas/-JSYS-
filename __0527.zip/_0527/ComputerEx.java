package _0527;


// 추상클래스
public abstract class ComputerEx {
	public abstract void display();
	public abstract void typing();

}
