package _0527;

public class Child extends Parent {
	
	private int id;
	
	public Child(String name) {
		super(name); //상위 클래스에서 받은 것을 명시 해줘야.
		this.name = name;
		this.id = id;
	}

	@Override
	public void info() {
		super.info();
		
	}


	
	

}
