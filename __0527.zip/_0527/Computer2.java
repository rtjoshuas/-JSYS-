package _0527;

public abstract class Computer2 {
	
	abstract void display();
	abstract void typing();

}
