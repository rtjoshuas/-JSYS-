package _0527;

import java.util.ArrayList;

public class CarMainClass {

	public static void main(String[] args) {
		ArrayList<Vehicle> list = new ArrayList<Vehicle>();
		
		list.add(new BusClass());
		list.add(new Taxi());
		list.add(new BusClass());
		list.add(new Taxi());
		list.add(new BusClass());
		
		
		Drive driver = new Drive();
		
		
		
		
	for (Vehicle vehicle : list) {
		driver.drive(vehicle);
		
	}
	}
}
