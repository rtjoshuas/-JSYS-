package _0527;

public class Vehicle {
	
	public void run() {
		System.out.println("달린다");
	}

}
