package _0527;

public class ParentMain {

	public static void main(String[] args) {
		Parent parent = new Parent("부모");
		parent.info();
		
		Child child = new Child("학생");
		child.info();

	}

}
