package _0527;

public abstract class NoteBook extends Computer2 {
	
	
	public display()
	{
		System.out.println("NoteBook dislay()");
	}

}
