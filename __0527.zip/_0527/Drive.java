package _0527;

public class Drive {
	
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}

}
