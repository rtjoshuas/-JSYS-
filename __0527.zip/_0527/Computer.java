package _0527;

public class Computer extends Calculator {
	
	public Computer() {
		
	}

	@Override
	public double areaCircle(double r) {
		
		super(areaCircle(r));
		
		return Math.PI*r*r;
	}
	

	}

}
