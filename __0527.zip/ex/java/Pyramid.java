package ex.java;


	
		public class Pyramid {

			public static void main(String[] args) {
				// 반복문 사용하여 피라미드 출력 (연습문제 p.123 / 4번)
			
				for(int i = 0; i < 4; i++) { // i 4번 반복(4줄)
					int j = 0;				// 싸이클 마다 초기화
					
					for(; j < 3-i; j++) {		// 0 j0 i0
						System.out.print(" ");
					}
					
					for(; j < 4+i; j++) {
						System.out.print("*");
					}

					System.out.println("");
				}

			}

		
	}


