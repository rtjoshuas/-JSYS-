package ex.java;

public class arrautest {

	public static void main(String[] args) {
		 
		// 숫자를 100개 담는 배열
		
		/*int[] arry = new int[100];
		int arry1[] = new int[100];
		
		int[]array2;
		
		while(true) {
			
			array2 = new int[100];
			for(int i = 0; i <100; i++) {
				
			}
		}*/

		
		// 학생 이름, 학번, 위치 정보를 100개 담은 자료를 선언
		// 예) "홍길동, 1020, 구로구"
		//-- > "홍길동 - 1020 - 구로구"
		// ",", "-" : 구분자, 분리자, Delimeter, Seperator
		
		String[] info = new String[100];
		//배열은 크기들을 정해놓는 것 장점 = 공간이 정해짐 단점은 동적
		info[0] = "홍길동, 1020, 구로구";
		info[1] = "홍수달, 1021, 부산 기장구";
//		info[2] = "홍길동 - 1020 - 구로구"; // 위와 같이 쓰다가 이렇게 쓰면 곤란
		
		for(int i = 0; i < info.length; i++) { //infolength만큼 돌기 때문에 아래 같이 코딩하면 에러
			String person = info[i];
			
			String [] data = person.split(",");
			
			System.out.println("이름: " + data[0]
								+ "학번:" + data[1]
								+ "위치 : " + data[2]);
			
			//err 왜? 98개가 비어 있어서
			
		}
		
		
		
		// 예2)
		// 이름: "홍길동"
		// 학번 : 1020
		// 위치 : 구로구
		
		String[] name = new String[100];
		String[] number = new String[100];
		String[] house = new String[100];
		name[0] = "홍길동"; number[0] = "1020"; house[0] = "시흥시";
		//name[0] = "홍길동"; number[1] = "1020"; 
		
		for(int i = 0; i < house.length; i++) {
			System.out.println("이름: " + name[i]
					+ "학번:" + number[i]
					+ "위치 : " + house[i]);
		// 중간에 빠진 것 까지 고민해야 하는 단점 so 동적 배열을 사용한다
		}
		
		//
		String[] info2 = new String[] {"",""};
		// = String[] info2 =  {"",""}; 위와 같이 채워넣고 쓰는게 좋다
		
		
		
	}

}
