package ex.day8;

import java.util.Scanner;

public class StudentMain {

	public static void main(String[] args) {
		Student[] student = new Student[5];
		
		Scanner sc = new Scanner(System.in);
		
		
		student[0] = new Student();
		student[1] = new Student();
		
		Score[] Score = new Score[3];
		Score[0] = new Score();
		Score[1] = new Score();
		Score[2] = new Score();
		
		System.out.println("학생 성적을 입력하세요 : 이름/학년/주소/수학/과학/영어");
		System.out.println("홍길동 :");
		
		
				
		student[0].name = sc.next();
		student[0].grade = sc.nextInt();
		student[0].address = sc.next();
//		student[0].science = "과학";
//		student[0].math = "수학";
//		student[0].eng = "영어";
		student[0].Score[0] = new Score();
		student[0].Score[1] = new Score();
		student[0].Score[2] = new Score();
		student[0].Score[0].score = sc.nextInt();
		student[0].Score[1].score = sc.nextInt();
		student[0].Score[2].score = sc.nextInt();
		
		System.out.print(student[0].name);
		System.out.print("/");
		System.out.print(student[0].age);
		System.out.print("/");
		System.out.print(student[0].grade);
		System.out.print("/");
		System.out.print(student[0].address);
		System.out.print("/");
		System.out.print(student[0].Score[0].score);
		System.out.print("/");
		System.out.print(student[0].Score[1].score);
		System.out.print("/");
		System.out.println(student[0].Score[2].score);
		
		System.out.println("학생 성적을 입력하세요 : 이름/학년/주소/수학/과학/영어");
		System.out.println("유재석 :");
		
		
		
		student[1].name = "유재석";
		student[1].name = sc.next();
		student[1].grade = sc.nextInt();
		student[1].address = sc.next();
//		student[1].science = "과학";
//		student[1].math = "수학";
//		student[1].eng = "영어";
		student[1].Score[0] = new Score();
		student[1].Score[1] = new Score();
		student[1].Score[2] = new Score();
		student[1].Score[0].score = sc.nextInt();
		student[1].Score[1].score = sc.nextInt();
		student[1].Score[2].score = sc.nextInt();
		
		System.out.print(student[1].name);
		System.out.print("/");
		System.out.print(student[1].age);
		System.out.print("/");
		System.out.print(student[1].grade);
		System.out.print("/");
		System.out.print(student[1].address);
		System.out.print("/");
		System.out.print(student[1].Score[0].score);
		System.out.print("/");
		System.out.print(student[1].Score[1].score);
		System.out.print("/");
		System.out.println(student[1].Score[2].score);
		
		System.out.println("이름/학년/주소/수학/과학/영어");
		
		System.out.println();
		
		

		
	}

}
