package ex.day8;

public class Student {
	
	String name;
	int age;
	int grade;
	String address;
	String science;
	String math;
	String eng;
	
	Score[] Score = new Score[3];
	
	
	
	
}
