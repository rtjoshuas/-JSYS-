package ex.day8;

public class Score {
	
	
	int score;
	String subject;
	

}
