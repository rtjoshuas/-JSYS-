package _0525;

import _0525_info.Person;

public class Chapter5Main {

	public static void main(String[] args) {
		Student st = new Student(); //_0525 
		
		Person p = new Person();
		
		// . operator로 Student 접근 가능
		st.studentId = 1000;
		st.studentName = "홍길동";
		
		
		// 사용시에도 
		System.out.println(st.studentName); //이렇게 접근 가능
		
		
		//st.studentName + st.studentId + st.address; // 메번 이렇게 출력하기 어렵기 때문에 메소드 사용
		
		
		// 2. 반환형식 있다.
		String info = st.showStudentInfo();
		System.out.println(info);
		
		System.out.println(st.showStudentInfo());
		// 3. 반환형식 없다.
		st.println();
		
		// 다른 패키지.
		ex.day8.Student st3 = new ex.day8.Student() ;
		
		// 4.매개변수
		info = st.setScore(1000);
		System.out.println(info);
		
		
		
		st.setScore2(1000);
		System.out.println(st.showStudentInfo());
		
		
		
	}

}
