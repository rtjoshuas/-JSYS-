package _0525;

public class RectangleMainEx {

	public static void main(String[] args) {
		Rectangle angle = new Rectangle();
		Rectangle angle1 = new Rectangle("홍길동", 32.2, 55.0);
		Rectangle angle2 = new Rectangle();
		angle.name = "홍길동";
		angle.width = 52.3;
		angle.height = 90.2;
		
		System.out.println(angle2.name);
		angle2.width = 43.2;
		angle2.height = 59.3;

	}

}
