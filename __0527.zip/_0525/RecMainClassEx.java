package _0525;

public class RecMainClassEx {

	public static void main(String[] args) {
		
		RecClassEx Rec = new RecClassEx(32.0, 23.1);
		RecClassEx Rec2 = new RecClassEx(11.9, 883.4);
		
		System.out.println(Rec.getArea());
		System.out.println(Rec2.getArea());
	}

}
