package _0525;

//  class 지시자 : 클래스의 코드를 정의
public class Student {
	
	//멤버 필드(변수, 식별자) : 속성
	String name;
	int studentId;
	int grade;
	String studentName;
	String address;
	int score;
	
	//멤버 메서드 : 함수
	//1. 클래스 안에서만 존재
	//2. 반환형식이 있다.
	
	public String showStudentInfo() {
		// 학생정보 : 이름 /아이디 /주소
		String info = studentName +"/"+ studentId +"/"+ address;
		return info; //형식이 같아야 한다
	}
	// 3. 반환이 없을 수 있따. : void
	//클래스 내부에서 연산/계산/처리 -> 클래스 내부에 저장.. 출력
	public void println(String info) {
		info = studentName +"/"+ studentId +"/"+ address;
		System.out.println(info);
	}
	// 4. 매개변수를 사용.
	// -> 점수 전달, 처리 인포 반환
	public String setScore(int score) {
		score = score;
		String info = showStudentInfo();
		return info + " / score=" + score;
		
	}
	public void setScore2(int score) {
		score = score;
		
	
}
}