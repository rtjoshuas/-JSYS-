package _0525;

public class OrderExMain {

	public static void main(String[] args) {
		OrderEx order = new OrderEx();
		
		order.orderNumber = 201803120001L;
		order.orderId = "JSYS";
		order.orderDate = "2018년 3월 12일";
		order.orderName = "JOSHUA";
		order.orderProductNumber = "PD0345-12";
		order.orderAddress = "서울시 영등포구 여의도동 20번지";
		
		
		order.print();
	}

}
