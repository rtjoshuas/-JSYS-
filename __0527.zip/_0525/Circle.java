package _0525;

public class Circle {
	String name;
	double radius;
	double area;
	float PI = 3.14f;
	
	public Circle(String n, double c) {
		name = n;
		radius = c;
	}
	
	public double getArea(double result) {
		result = radius * radius * 3.14;
		return result;
	}

}
