package _0525;

public class PersonExam {
	
	String name;
	int age;
	String gender;
	boolean married;
	int child; // 
	
	public void print() {
		System.out.println("01_이름 : " + name);
		System.out.println("02_나이 : " + age);
		System.out.println("03_결혼 : " + married);
		System.out.println("04_자녀 : " + child);
	}

}
