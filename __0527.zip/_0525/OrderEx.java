package _0525;

public class OrderEx {
	
	long orderNumber;
	String orderId;
	String orderDate;
	String orderName;
	String orderProductNumber;
	String orderAddress;
	
	
	public void print() {
		System.out.println("주문 번호 : " + orderNumber);
		System.out.println("주문자 아이디 : " + orderId);
		System.out.println("주문 날짜 : "  + orderDate);
		System.out.println("주문자 이름 : " + orderName);
		System.out.println("주문 상품 번호 : "  + orderProductNumber);
		System.out.println("배송 주소 : " + orderAddress);

		
	}

}
