package _0525;

public class CircleMain {

	public static void main(String[] args) {
		Circle c1 = new Circle("홍", 30.2);
		Circle c2 = new Circle("초", 55.2);
		
		System.out.println(c1.name + c1.getArea());
		System.out.println(c2.name + c2.getArea());
		 

	}

}
