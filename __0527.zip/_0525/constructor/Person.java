package _0525.constructor;

public class Person {
	
	String name;
	float height;
	float weight;
	
	
	//특별한 메소드이다
	//생성자는 class 이름과 같다
	// return 타입 선언이 없다
	public Person() {
		height = 0;
		weight = -1;

		System.out.println("Person 생성자" + "W: " + weight + "  H: " + height);
		}
		// 2. 매개변수 생성자
		public Person(String n) {
			 name = n;
			 System.out.println(name + "W: " + weight + "  H: " + height);
		
	}
		public Person(String n, float w, float h) {
			 name = n;
			 weight = w;
			 height = h;
			 System.out.println(name + "W: " + weight + "  H: " + height);
		}
	
}
