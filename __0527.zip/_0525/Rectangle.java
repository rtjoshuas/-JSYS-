package _0525;

public class Rectangle {
	String name;
	double width;
	double height;
	
	
	
	
	public Rectangle(String n, double w, double h){
		name = n;
		width = w;
		height = h;
		
		System.out.println("이름 : " + n);
		System.out.println("너비 : " + w);
		System.out.println("폭 : " + h);
	}
	
	public Rectangle() {
		name = "뭐뭐";
		width = 0;
		
	}
	

}
