package _0525;

public class FunctionTest {

	public static void main(String[] args) {


		int num1 = 10;
		int num2 = 20;
	
		                                                                                  
	}

}
