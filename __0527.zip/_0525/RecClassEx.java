package _0525;

public class RecClassEx {
	double height;
	double width;
	double area;
	
	
	
	public RecClassEx(double h, double w) {
		height = h;
		width = w;
		
	}
	
	
	public double getArea() {
		double result;
		result = height*width;
		return result;
				
	}
	
}
