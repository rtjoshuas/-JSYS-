package _0521;

public class Score2 {
	// 과목 + 점수
	String subject; // 과목
	int score;		// 점수
	
	//String [0]  = new String[];
	//String [1] = new String[];
	//mana[0] = "수학 100, 국어 90";
	//mana[1] = "수학 70, 국어 80";
	

}
