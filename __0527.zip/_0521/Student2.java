package _0521;

public/*접근 제어자*/ class Student2
{// <code block	// class 지시자 : 클래스의 코드를 정의하는 곳
	
	// 멤버 필드(변수, 식별자) :속성
	
	int studentId;
	String studentName;
	int grade;
	String address;
	
	//과목별 점수: 과목 + 점수
	//Score2 subj;
	Score2[] subj;
	
	// 멤버 메서드 : 함수
	
	

	// 순서는 상관이 없다 위에 있든 아래에 있든
	
}



//class Person{ //다른 클래스에서도 많이 쓰면(관계) 퍼블릭에서 분리 시켜라
//	String name;
//	int age;
//	char gender; // 불리언 값도 괜챊다
	//byte s; //s: 0 남자, s: 1 여자, 나머지 x
//}
