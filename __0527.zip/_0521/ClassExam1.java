package _0521;

public class ClassExam1 {

	public static void main(String[] args) {
		
		

	}

}
