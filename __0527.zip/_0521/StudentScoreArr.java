package _0521;

import java.util.Scanner;

public class StudentScoreArr {

	public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			
		String[] stu = new String[5];
			String name = sc.
		int math = 0;
		int sci = 0;
		
		int find_id = -1;
		
		for(int i = 0; i < stu.length; i++) {
			
			stu[i] = sc.next();                  //stu 
			String person = stu[i];
			
			
			String[] data = person.split("/");  //구분자
			//학생 찾기 // 휴대폰 사진에 
			if(person[0].contains(name)){
				find_id = i;
				break;
			}
			
			math += Integer.parseInt(data[1]);
			
			sci += Integer.parseInt(data[2]);
		
		 System.out.println("------------------");
		 
		
		
				
//		String [] data = science.split("/");
		
//		System.out.println(data[]);
		
		
		
		}
		
	}

}
