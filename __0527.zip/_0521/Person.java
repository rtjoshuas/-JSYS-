package _0521;

public class Person {


	//멤버 필드(변수)
		String name;	
		int height;
		double weight;
		char gender; // 불리언 값도 괜챊다
		boolean married;
		
	
}
