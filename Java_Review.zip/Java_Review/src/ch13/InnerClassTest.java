package ch13;

import ch10.Buy;

public class InnerClassTest {
	
	
	//인스턴스 내부 클래스
	
	class InnerClass{
		String name; // 필드 갖을 수 있고
		
		static final int a = 0; //static은 파이널로 
		
		void info() { //메소드 갖을 수 있다
			
		}
	}
	
	private int num = 10;
	private static int snum= 10;
	// 정적 내부 클래스
	static class StaticInnerClass{
		int a = 0;
		static int i = 0;
		void info() {
			//num += 1;
			snum += 10;
		}
	}
		
	// 지역 내부 클래스 -> method 내부
	public void local() {
		// Test t1 = new Test();

		class Test{
			int a;
			String n;
		}
		Test t= new Test();
	}
	
	public Runnable getRunnable() {
		
		class MyRunnable implements Runnable{

			@Override
			public void run() {
				// TODO Auto-generated method stub
				
			}
			
		} return new MyRunnable();
	}
	
	public int getint() {
		return 0;
	}
	
	// 익명 내부 클래스
	
	Object o = new Object() {
		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return super.toString();
		}
	};
	
	public Object getobj() {
		return new Object() {
			@Override
			public String toString() {
				// TODO Auto-generated method stub
				return super.toString();
			}
		};
	}
	
	Buy b = new Buy() {
		public void buy() {};
	};
	

}
