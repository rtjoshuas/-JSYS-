package review;

public class OperatorEx1 {

	public static void main(String[] args) {
		
		// 비트 논리 연산자
		// 값의 각각의 비트에 대해서 &, |, ^, ~
		
		// & 연산
		int num1 = 23;
		int num2 = 45;
		System.out.println("23: " + Integer.toBinaryString(num1));
		System.out.println("45: " + Integer.toBinaryString(num2));
		System.out.println("23 & 45: " + Integer.toBinaryString(num1 & num2));
		System.out.println("23 | 45: " + Integer.toBinaryString(num1 | num2));
		System.out.println("23 ^ 45: " + Integer.toBinaryString(num1 ^ num2));

		
		System.out.println("~23: " + Integer.toBinaryString(~num1));
//		num1 && num2; 참 거짓 : true, false
		
		int num3 = 0;
		num3 &= num1;
		System.out.println("23 &= 45 : " + Integer.toBinaryString(num1 &= num2));
		num3 |= num2;
		System.out.println("23 | 45 : " + Integer.toBinaryString(num3));
		num3 ^= num2;
		System.out.println("23 ^ 45 : " + Integer.toBinaryString(num3));
		
		
		// 비트 이동:
		// 객체 << 이동횟수, 객체 >> 이동횟수,

		System.out.println("23 << 2 : " + Integer.toBinaryString(23 << 2));
		System.out.println("23 >> 2 : " + Integer.toBinaryString(23 >> 2));
		
		num2 = 0B00000101;
		System.out.println("5 >> 2 : " + Integer.toBinaryString(num2 << 2));

		System.out.println("5 >>> 2 : " + Integer.toBinaryString(num2 >>> 2));
		

		
		
		
		
		//복합대입
		//대입*연산자: +=, -=, *=, /=, %=
		// 시프트 복합: >>=, <<=, >>>=
		// 논리비트 복합: &=, |=, ^\
		num1 += 2; // num1 = num1 + 2
		System.out.println("+=: " + (num1 += 2));
		System.out.println("+=: " + num1);

		
		System.out.println("-=: " + (num1 -= 2));
		System.out.println("*=: " + (num1 *= 2));
		System.out.println("/=: " + (num1 /= 2));
		
	}

}
