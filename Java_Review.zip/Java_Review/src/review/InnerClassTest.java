package review;
//외부클래스
public class InnerClassTest {
	
	
	// 2. static innerclass
	
	
	
	
	//맴버
	InnerClass inner;

	//1.인스턴스 이너클래스 
	
	class InnerClass{
		private int a;
		// static은 제한
		//static String name;
		
		//final 을 붙이면  static 도 상수로 사용가능
		final static String name = "";
		
		
		public void info() {
			
		}
	}
	
	static class StaticInnerClass{
		
		static int name;
		
		public void info() {
			
		}
		public static void info2() {
			
		}
		
	}
	
	// 3. Local innerclass

	public void test() { //매소드
		int a; // 지역변수
		
//		LocalInnerClass local;
//		local = new LocalInnerClass();
		
		
		class LocalInnerClass{ //지역클래스
			private String name;
			
			public LocalInnerClass() { //생성자
			}
			
			public String info() { //매소드
				return this.name; //로컬 클래스
			}
		}
		
		LocalInnerClass local;
		local = new LocalInnerClass();
		
	}
	
	// 4. Anonymouse Innerclass
	public Object getObject() {
		return new Object() {
			@Override
			public String toString() {
				// TODO Auto-generated method stub
				return "별점: " + 1000;
			}
		};
	}
	public Object getObject2() {
		
		Object obj = new Object() {
			@Override
			public String toString() {
				// TODO Auto-generated method stub
				return "별점: " + 1000;
			}
			
		};
		
		return obj;
	}
	
	
	
	
	
	public static void main(String[] args) {
		// 인스턴스 이너 클래스 객체
		InnerClassTest out = new InnerClassTest();
		InnerClass io = out.new InnerClass();
	
		// 2. static class 사용 //new 없어도 사용가능
		System.out.println(StaticInnerClass.name);
		StaticInnerClass.info2();
	}
	
		
	

}
