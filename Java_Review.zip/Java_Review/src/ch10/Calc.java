package ch10;

public interface Calc {
	
	double PI = 3.14;
	int ERROR = -99999999;
//	static final int PP = 0;
	
	
	static int total(int[] arr) {
		int t = 0;
		for(int i : arr) {
			t +=i;
		}
		myStaticMethod();
		return t;
		
	}
	
	
	
	int add(int num1, int num2);
	int substract(int num1, int num2);
	int times(int num1, int num2);
	int divide(int num1, int num2);
	
	//인터페이스에선 메소드 X
	default void description() {// 디폴트 메소드는 가능
		System.out.println("정수 계산기를 구현합니다.");

	}
	
	//private 메소드는 디폴드 메소드에서 쓰기 위함. static도 가능
	private void myMethod() {
		System.out.println("private 메서드");
	}
	
	private static void myStaticMethod() {
		System.out.println("private static 메서드");
	}
		
	
	
	
	
}
