package ch10;

public interface Y {
	void y();
}
