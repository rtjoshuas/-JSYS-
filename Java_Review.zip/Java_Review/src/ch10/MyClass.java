package ch10;

public class MyClass implements MyInterface {

	@Override
	public void x() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void y() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void myMethod() {
		// TODO Auto-generated method stub
		
	}

}
