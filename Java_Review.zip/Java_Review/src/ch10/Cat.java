package ch10;

public class Cat implements Soundable {

	@Override
	public String sound() {
		
		return "냥";
	}

}
