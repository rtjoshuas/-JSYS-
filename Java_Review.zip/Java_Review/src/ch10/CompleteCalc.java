package ch10;

public class CompleteCalc extends Calculator{
	
	@Override  //인터페이스 디폴드 메소드 재정의
	public void description() {
		System.out.println("인터페이스 메소드 재정의 계산");
	}

	@Override
	public int divide(int num1, int num2) {
			if(num2 != 0)
				return num1/num2;
			else
				return Calc.ERROR;
	}
	
	@Override
	public int times(int num1, int num2) {
		
		return num1 * num2;
	}

}
