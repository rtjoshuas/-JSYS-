package ch10;

public interface Soundable {
	
	String sound();
	

}
