package ch10;

public interface Sell {
	void sell();
	


}
