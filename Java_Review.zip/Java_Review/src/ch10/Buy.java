package ch10;

public interface Buy {
	void buy();


}
