package ch10;

public interface MyInterface extends X, Y {
	void myMethod();

}
