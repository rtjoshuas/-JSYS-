package ch12;

public class GenericTest {
	public void print() {
		ThreeD printer = new ThreeD();
		Plastic p = new Plastic();
		printer.setMaterial(p);
		Object m = printer.getMaterial();
		
		Plastic pp = (Plastic)m;
		
		//Generic clags
		GenericPrinter<Powder> powderPrinter = new GenericPrinter();
		powderPrinter.setMaterial(new Powder());
		
		Powder pp2 = powderPrinter.getMaterial();
		
	}
}

class GenericPrinter<T> {
	private T material;
	void setMaterial(T o) {
		this.material = o;
	}
	T getMaterial() {
		return this.material;
	}
}

class ThreeD{
	private Object setMaterial;
	
	
}

class Plastic{
	
}
class Powder{
	
}
