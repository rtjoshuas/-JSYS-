package ch04;

public class ControlExample {

	public static void main(String[] args) {
		int age = 10;
		System.out.println(age >= 6);
		System.out.println(age <= 6);
		System.out.println(age & 6);
		
		if(age >= 6) {
			System.out.println("나이가 " + age);
		} else {
			System.out.println("다시");
		}
		
		
		// P95
		char gender = 'F';
		System.out.println((int)gender);
		// F인지?
		if(gender == 'F') {
		System.out.println("여성");
		}else {
			System.out.println("남성");
		}
		
		if(gender == 70) {
			System.out.println("여성");
		}else {
			System.out.println("남성");
		}
		
		if(gender != 70) {
			System.out.println("남성");
		}else {
			System.out.println("여성");
		}
		
		if(gender != 70) 
			System.out.println("남성");
			//System.out.println("남성"); 중괄호 없는 경우 2가지 출력하면 else 에러
		else 
			System.out.println("여성");
		
		if(gender != 70) { 
		System.out.println("남성");
		//System.out.println("남성"); 중괄호 없는 경우 2가지 출력하면 else 에러
		}else {
		System.out.println("여성");}
	
	
	//조건식 : 이항 관계연산자
	
	//산술식과 함께는? 산술식이 단독으로 들어가지 않는다
	
	if((1+1) > 0) {
		
	}
	
	// 삼항연산자 적용?
	//조건식 ? 참 : 거짓 값 반환
	System.out.println(gender != 70 ? "남성" : "여성");
	
	
	//복합  if-else if-else
	
	age = 8;
	int charge = 0;
	
	if(age < 8) {
		charge = 1000;
	} else if(age < 14) {
		charge = 2000;
	} else if(age < 20) {
		charge = 2500;
	} else {
		charge = 3000;
	}
	
	
	
	System.out.println((age < 8) ? 1000 : (age < 14) ? 2000 : 2500);

	
	//P100
	int score = 60;
	char grade = 'z';
	
	if(score > 90) {
		grade = 'A';
	}else if (score > 80) {
		grade = 'B';
	}else if (score > 70) {
		grade = 'C';
	}else if (score > 60) {
		grade = 'D';
	}else {
		grade = 'F';
	}
	System.out.println(grade);
	
	if((score > 60) && score < 69) {
		grade = 'D';
	}else if ((score > 70) && (score < 79)) {
		grade = 'C';
	}else if ((score > 80) && (score  < 89)) {
		grade = 'B';
	}else if ((score > 90) && (score < 100)) {
		grade = 'A';
	}else {
		grade = 'F';
	}
	
	
	//Nested if
	// 95 : A+ , 90 > : A
	String grd = "";
	if(score > 90) {
		if(score < 95) {
			grd= "A+";
		}else {
			grd = "A";
		} if(score >= 85) {
			grd = "B+";
		} else {
			grd = "B";
		}
	}
	
	
	// switch - case
	
	int rank = 20; // 입력된 값
	
	switch(rank) { // key : 숫자형(정수형, char형), 문자
	
	case 10:
		System.out.println("10");
		break;
	case 20:
	case 30:  // 20, 30 붙어서 진행하면 or 로 진행
		System.out.println("20 30");
		break;
	case 40:
	case 50:{
		System.out.println("40 50");
		break;
	}
	
	default:
		System.out.println("end");
	}
	
	// switch char
	grade = 'D';
	
	switch(grade) {
	case 'A' :
		System.out.println('A');
		break;
	case 'B' :
		System.out.println("B");
		break;
	case 'C' :
		System.out.println("C");
		break;
	case 'D' :
		System.out.println("D");
		break;
	default :
		System.out.println("F");
	}
	
	// jdk1.8 이상
	String position = "이사";
	switch(position) {
	case "과장":
		break;
	case "차장":
		break;
	case "이사":
		break;
	default:
	}
	
	// 해당하는 월의 게절 값 출력 
	// 1 , 2, 12 : 겨울
	// 3, 4, 5 : 봄
	// 6, 7, 8 : 여름
	// 9, 10, 11 : 가을
	
	int month = 2;
	
	if((month == 12) || (month == 2) || (month == 1)) {
		System.out.println("겨울");
	} else if((month == 3) || (month == 4) || (month == 5)) {
		System.out.println("봄");
	} else if((month == 6) || (month == 7) || (month == 8)) {
		System.out.println("여름");
	} else {
		System.out.println("가을");
	}
	
	String season = "";
	
	switch(month) {
	case 12:
	case 1:
	case 2:{
		season = "겨울";
	} break;
	case 3:
	case 4:
	case 5: {
		season = "봄";
	}	break;
	case 6:
	case 7:
	case 8: {
		season = "여름";
	}	break;
	case 9:
	case 10:
	case 11:{
		season = "가을";
	}break;
	default:
	}
		System.out.println(season);
	
	
	
	
	

	}

}
