package ch04;

public class LoopBasic {

	public static void main(String[] args) {

		// while(조건식) {코드블럭}
		
		// 1~10 자연수를 각각 더해서 합을 출력
		
		int num = 1;
		int sum = 0;
		
		while(num <= 10) { // num 증가 + 1
			
			sum = num + sum;
			//sum += num;
			// 마지막
			// ++num;
			// num = num + 1;
			// num += 1;
			// num++;
			
			
		}
		
		System.out.println("1부터 10까지 합 : " + sum);
		
		// 1부터 10까지 수에서 짝수인 경우만 합
		
		num = 1;
		sum = 0;
		
		while(num <= 10) {
			if(num % 2 == 0) {
				sum += num;
			}
			num++;
		}
		System.out.println(sum);
		
		
		// do while
		
		num = 1;
		sum = 0;
		
		do {
			sum += num;
			num++;
		} while(num <= 10);
		System.out.println(sum);
		
		

		// for
		
		// for each
		
		

	}

}
